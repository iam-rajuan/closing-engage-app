#include <reanimated/CSS/registries/CSSKeyframesRegistry.h>
#include <reanimated/Fabric/updates/UpdatesRegistryManager.h>

#include <react/debug/react_native_assert.h>

#include <string>
#include <utility>

namespace reanimated::css {

std::optional<std::reference_wrapper<const CSSKeyframesConfig>> CSSKeyframesRegistry::get(
    const std::string &animationName,
    const std::string &compoundComponentName) {
  react_native_assert(UpdatesRegistryManager::isLockedByCurrentThread());
  const auto registryIt = registry_.find(animationName);
  if (registryIt == registry_.end()) {
    return std::nullopt;
  }

  const auto &keyframesByComponent = registryIt->second;
  const auto keyframesByComponentIt = keyframesByComponent.find(compoundComponentName);
  if (keyframesByComponentIt == keyframesByComponent.end()) {
    return std::nullopt;
  }

  return std::cref(keyframesByComponentIt->second);
}

void CSSKeyframesRegistry::set(
    const std::string &animationName,
    const std::string &compoundComponentName,
    CSSKeyframesConfig &&config) {
  react_native_assert(UpdatesRegistryManager::isLockedByCurrentThread());
  registry_[animationName][compoundComponentName] = std::move(config);
}

void CSSKeyframesRegistry::remove(const std::string &animationName, const std::string &compoundComponentName) {
  react_native_assert(UpdatesRegistryManager::isLockedByCurrentThread());
  registry_[animationName].erase(compoundComponentName);
  if (registry_[animationName].empty()) {
    registry_.erase(animationName);
  }
}

} // namespace reanimated::css
