require "json"
require_relative './scripts/reanimated_utils'

reanimated_package_json = JSON.parse(File.read(File.join(__dir__, "package.json")))
config = ReanimatedUtils.find_config()
ReanimatedUtils.assert_minimal_react_native_version(config)

boost_compiler_flags = '-Wno-documentation'
example_flag = config[:is_reanimated_example_app] ? '-DIS_REANIMATED_EXAMPLE_APP' : ''
reanimated_profiling_flag = ENV['IS_REANIMATED_PROFILING'] ? '-DREANIMATED_PROFILING' : ''
version_flag = "-DREANIMATED_VERSION=#{reanimated_package_json['version']}"
ios_min_version = '13.4'

# Directory in which data for further processing for clangd will be stored.
compilation_metadata_dir = "CompilationDatabase"
# We want generate the metadata only within the monorepo of Reanimated.
compilation_metadata_generation_flag = config[:is_reanimated_example_app] ? "-gen-cdb-fragment-path #{compilation_metadata_dir}" : ''

feature_flags = "-DREANIMATED_FEATURE_FLAGS=\"#{ReanimatedUtils.get_static_feature_flags()}\""

Pod::Spec.new do |s|

  s.name         = "RNReanimated"
  s.version      = reanimated_package_json["version"]
  s.summary      = reanimated_package_json["description"]
  s.description  = <<-DESC
                  RNReanimated
                   DESC
  s.homepage     = "https://github.com/software-mansion/react-native-reanimated"
  s.license      = "MIT"
  s.author       = { "author" => "author@domain.cn" }
  s.platforms    = { :ios => ios_min_version, :tvos => "9.0", :osx => "10.14", :visionos => "1.0" }
  s.source       = { :git => "https://github.com/software-mansion/react-native-reanimated.git", :tag => "#{s.version}" }

  s.dependency "RNWorklets"

  s.header_dir = "reanimated"
  
  s.subspec "common" do |ss|
    ss.source_files = "Common/cpp/reanimated/**/*.{cpp,h}"
    ss.public_header_files = "Common/cpp/reanimated/**/*.h"
    ss.header_mappings_dir = "Common/cpp/reanimated"
  end

  s.subspec "apple" do |ss|
    ss.source_files = "apple/reanimated/**/*.{mm,h,m}"
    ss.public_header_files = "apple/reanimated/**/*.h"
    ss.header_mappings_dir = "apple/reanimated"
  end

  s.subspec "view" do |ss|
    ss.source_files = "Common/NativeView/**/*.{mm,h,cpp}"
    ss.header_dir = ""
    ss.header_mappings_dir = "Common/NativeView"
  end

  s.pod_target_xcconfig = {
    "USE_HEADERMAP" => "YES",
    "DEFINES_MODULE" => "YES",
    "HEADER_SEARCH_PATHS" => [
      '"$(PODS_TARGET_SRCROOT)/ReactCommon"',
      '"$(PODS_TARGET_SRCROOT)"',
      '"$(PODS_ROOT)/RCT-Folly"',
      '"$(PODS_ROOT)/boost"',
      '"$(PODS_ROOT)/boost-for-react-native"',
      '"$(PODS_ROOT)/DoubleConversion"',
      '"$(PODS_ROOT)/Headers/Private/React-Core"',
      '"$(PODS_ROOT)/Headers/Private/Yoga"',
      '"$(PODS_ROOT)/Headers/Public/RNWorklets"',
    ].join(' '),
    "FRAMEWORK_SEARCH_PATHS" => '"${PODS_CONFIGURATION_BUILD_DIR}/React-hermes"',
    "CLANG_CXX_LANGUAGE_STANDARD" => "c++20",
    "GCC_PREPROCESSOR_DEFINITIONS[config=*Debug*]" => '$(inherited)',
    "GCC_PREPROCESSOR_DEFINITIONS[config=*Release*]" => '$(inherited)',
  }
  s.compiler_flags = boost_compiler_flags
  s.xcconfig = {
    "HEADER_SEARCH_PATHS" => [
      '"$(PODS_ROOT)/boost"',
      '"$(PODS_ROOT)/boost-for-react-native"',
      '"$(PODS_ROOT)/glog"',
      '"$(PODS_ROOT)/RCT-Folly"',
      '"$(PODS_ROOT)/Headers/Public/React-hermes"',
      '"$(PODS_ROOT)/Headers/Public/hermes-engine"',
      '"$(PODS_ROOT)/Headers/Public/RNWorklets"',
      # for static frameworks
      "\"$(PODS_ROOT)/#{config[:react_native_common_dir]}\"",
      "\"$(PODS_ROOT)/#{config[:react_native_common_dir]}/jsitooling\"",
    ].join(' '),
    "OTHER_CFLAGS" => "$(inherited) #{example_flag} #{version_flag} #{compilation_metadata_generation_flag} #{feature_flags} #{reanimated_profiling_flag}",
  }
  s.requires_arc = true

  install_modules_dependencies(s)

  s.dependency 'React-jsi'
  s.dependency 'React-hermes'
end
