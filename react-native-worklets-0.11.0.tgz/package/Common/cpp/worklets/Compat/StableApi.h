#pragma once

/**
 * Version of `react-native-worklets` which introduced current stable API.
 * It can be used by libraries to verify they use a compatible version
 * of `react-native-worklets` installed when integrating in C++.
 */
#define WORKLETS_STABLE_API_VERSION "0.9.0"

#include <cstdint>
#include <functional>
#include <memory>
#include <string>

namespace facebook::jsi {
class Runtime;
class Value;
class Object;
class Function;
} // namespace facebook::jsi

namespace worklets {

class WorkletRuntime;
class UIScheduler;

class Serializable {
 public:
  virtual facebook::jsi::Value toJSValue(facebook::jsi::Runtime &rt) = 0;

  virtual ~Serializable();

  enum class ValueType : std::uint8_t {
    UndefinedType,
    NullType,
    BooleanType,
    NumberType,
    BigIntType,
    StringType,
    ObjectType,
    ArrayType,
    MapType,
    SetType,
    WorkletType,
    RemoteFunctionType,
    HandleType,
    HostObjectType,
    HostFunctionType,
    ArrayBufferType,
    TurboModuleLikeType,
    ImportType,
    SynchronizableType,
    CustomType,
    SymbolType, /* unused */
    ShareableType,
    ErrorType,
    RegExpType,
  };

  explicit Serializable(ValueType valueType) : valueType_(valueType) {}

  inline ValueType valueType() const {
    return valueType_;
  }

  static std::shared_ptr<Serializable> undefined();

 protected:
  ValueType valueType_;
};

extern std::shared_ptr<WorkletRuntime> getWorkletRuntimeFromHolder(
    facebook::jsi::Runtime &rt,
    const facebook::jsi::Object &object);

extern std::shared_ptr<UIScheduler> getUISchedulerFromHolder(
    facebook::jsi::Runtime &rt,
    const facebook::jsi::Object &object);

extern facebook::jsi::Runtime &getJSIRuntimeFromWorkletRuntime(const std::shared_ptr<WorkletRuntime> &workletRuntime);

extern std::weak_ptr<WorkletRuntime> getWeakRuntimeFromJSIRuntime(facebook::jsi::Runtime &rt);

extern void scheduleOnUI(const std::shared_ptr<UIScheduler> &uiScheduler, const std::function<void()> &job);

extern std::string JSIValueToStdString(facebook::jsi::Runtime &rt, const facebook::jsi::Value &value);

extern std::shared_ptr<Serializable>
extractSerializable(facebook::jsi::Runtime &rt, const facebook::jsi::Value &value, const std::string &errorMessage);

extern std::shared_ptr<Serializable> extractSerializable(
    facebook::jsi::Runtime &rt,
    const facebook::jsi::Value &value,
    const std::string &errorMessage,
    const Serializable::ValueType expectedType);

extern void runSyncOnRuntime(
    const std::shared_ptr<WorkletRuntime> &workletRuntime,
    const std::shared_ptr<Serializable> &worklet);

extern void runSyncOnRuntime(
    const std::shared_ptr<WorkletRuntime> &workletRuntime,
    const std::shared_ptr<Serializable> &worklet,
    const facebook::jsi::Value &arg0);

extern void runSyncOnRuntime(
    const std::shared_ptr<WorkletRuntime> &workletRuntime,
    const std::shared_ptr<Serializable> &worklet,
    const facebook::jsi::Value &arg0,
    const facebook::jsi::Value &arg1);

extern void runSyncOnRuntime(
    const std::shared_ptr<WorkletRuntime> &workletRuntime,
    const facebook::jsi::Function &worklet);

extern void runSyncOnRuntime(
    const std::shared_ptr<WorkletRuntime> &workletRuntime,
    const facebook::jsi::Function &worklet,
    const facebook::jsi::Value &arg0);

using RequestAnimationFrameHostFunction =
    std::function<void(facebook::jsi::Runtime &rt, const facebook::jsi::Value &callback)>;

extern void installRequestAnimationFrame(
    facebook::jsi::Runtime &uiRuntime,
    const RequestAnimationFrameHostFunction &requestAnimationFrame);

} // namespace worklets
