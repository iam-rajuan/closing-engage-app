#include <worklets/NativeModules/JSIWorkletsModuleProxy.h>
#include <worklets/WorkletRuntime/RuntimeData.h>
#include <worklets/WorkletRuntime/RuntimeManager.h>

#include <memory>
#include <string>
#include <utility>
#include <vector>

namespace worklets {

#ifndef NDEBUG
namespace {
void evaluateModuleUpdate(
    const std::shared_ptr<WorkletRuntime> &workletRuntime,
    const std::string &code,
    const std::string &sourceUrl) {
  workletRuntime->runSync([&code, &sourceUrl](jsi::Runtime &rt) -> void {
    const auto buffer = std::make_shared<jsi::StringBuffer>(code);
    rt.evaluateJavaScript(buffer, sourceUrl);
  });
}
} // namespace
#endif // NDEBUG

std::shared_ptr<WorkletRuntime> RuntimeManager::getRuntime(uint64_t runtimeId) {
  std::shared_lock lock(weakRuntimesMutex_);
  if (weakRuntimes_.contains(runtimeId)) {
    return weakRuntimes_.at(runtimeId).lock();
  }
  return nullptr;
}

std::vector<std::shared_ptr<WorkletRuntime>> RuntimeManager::getAllRuntimes() {
  std::shared_lock lock(weakRuntimesMutex_);

  std::vector<std::shared_ptr<WorkletRuntime>> runtimes;
  runtimes.reserve(weakRuntimes_.size());

  for (const auto &[id, weakRuntime] : weakRuntimes_) {
    if (auto runtime = weakRuntime.lock()) {
      runtimes.push_back(runtime);
    }
  }

  return runtimes;
}

std::shared_ptr<WorkletRuntime> RuntimeManager::getUIRuntime() {
  return getRuntime(RuntimeData::uiRuntimeId);
}

std::shared_ptr<WorkletRuntime> RuntimeManager::createWorkletRuntime(
    const std::shared_ptr<const JSIWorkletsModuleProxy> &sourceProxy,
    const std::string &name,
    const std::shared_ptr<SerializableWorklet> &initializer,
    const std::shared_ptr<AsyncQueue> &queue,
    bool enableEventLoop) {
  const auto runtimeId = getNextRuntimeId();

  const auto workletRuntime =
      std::make_shared<WorkletRuntime>(runtimeId, RuntimeData::RuntimeKind::Worker, name, queue, enableEventLoop);
  const auto targetProxy = JSIWorkletsModuleProxy::createForNewRuntime(sourceProxy, runtimeId);

  workletRuntime->init(targetProxy);

#ifndef NDEBUG
  withRegistrationPaused([&] { loadModuleUpdates(workletRuntime); });
#endif // NDEBUG

  if (initializer) {
    workletRuntime->runSync(initializer);
  }

  registerRuntime(runtimeId, workletRuntime);

  return workletRuntime;
}

#ifndef NDEBUG
void RuntimeManager::propagateModuleUpdate(const std::string &code, const std::string &sourceUrl) {
  std::unique_lock registrationLock(registrationMutex_);

  moduleUpdates_.push_back(ModuleUpdate{.sourceUrl = sourceUrl, .code = code});

  for (const auto &runtime : getAllRuntimes()) {
    evaluateModuleUpdate(runtime, code, sourceUrl);
  }
}

void RuntimeManager::loadModuleUpdates(const std::shared_ptr<WorkletRuntime> &workletRuntime) {
  for (const auto &update : moduleUpdates_) {
    evaluateModuleUpdate(workletRuntime, update.code, update.sourceUrl);
  }
}
#endif // NDEBUG

std::shared_ptr<WorkletRuntime> RuntimeManager::createUninitializedUIRuntime(
    const std::shared_ptr<AsyncQueue> &uiAsyncQueue) {
  const auto uiRuntime = std::make_shared<WorkletRuntime>(
      RuntimeData::uiRuntimeId,
      RuntimeData::RuntimeKind::UI,
      RuntimeData::uiRuntimeName,
      uiAsyncQueue,
      /*enableEventLoop*/ false);

  registerRuntime(RuntimeData::uiRuntimeId, uiRuntime);

  return uiRuntime;
}

uint64_t RuntimeManager::getNextRuntimeId() {
  return nextRuntimeId_.fetch_add(1, std::memory_order_relaxed);
}

void RuntimeManager::registerRuntime(const uint64_t runtimeId, const std::shared_ptr<WorkletRuntime> &workletRuntime) {
  std::unique_lock registrationLock(registrationMutex_);
  std::unique_lock lock(weakRuntimesMutex_);
  weakRuntimes_[runtimeId] = workletRuntime;
}

} // namespace worklets
