#import <worklets/NativeModules/JSIWorkletsModuleProxy.h>
#import <worklets/Tools/RNRuntimeStatus.h>
#import <worklets/Tools/ScriptBuffer.h>
#import <worklets/Tools/SingleInstanceChecker.h>
#import <worklets/WorkletRuntime/RNRuntimeWorkletDecorator.h>
#import <worklets/apple/AnimationFrameQueue.h>
#import <worklets/apple/AssertJavaScriptQueue.h>
#import <worklets/apple/AssertTurboModuleManagerQueue.h>
#import <worklets/apple/IOSUIScheduler.h>
#import <worklets/apple/WorkletsModule.h>

#import <React/RCTBridge+Private.h>
#import <React/RCTCallInvoker.h>

#ifdef WORKLETS_FETCH_PREVIEW_ENABLED
#import <FBReactNativeSpec/FBReactNativeSpec.h>
#import <React/RCTNetworking.h>
#import <ReactCommon/RCTTurboModule.h>
#import <worklets/apple/Networking/WorkletsNetworking.h>
#endif // WORKLETS_FETCH_PREVIEW_ENABLED

using namespace worklets;

@interface RCTBridge (JSIRuntime)
- (void *)runtime;
@end

@implementation WorkletsModule {
  AnimationFrameQueue *animationFrameQueue_;
  std::shared_ptr<WorkletsModuleProxy> workletsModuleProxy_;
  std::shared_ptr<RNRuntimeStatus> rnRuntimeStatus_;
#ifdef WORKLETS_FETCH_PREVIEW_ENABLED
  WorkletsNetworking *workletsNetworking_;
#endif // WORKLETS_FETCH_PREVIEW_ENABLED
#ifndef NDEBUG
  SingleInstanceChecker<WorkletsModule> singleInstanceChecker_;
#endif // NDEBUG
}

- (std::shared_ptr<WorkletsModuleProxy>)getWorkletsModuleProxy
{
  AssertJavaScriptQueue();
  return workletsModuleProxy_;
}

@synthesize bundleManager = bundleManager_;
@synthesize callInvoker = callInvoker_;
#ifdef WORKLETS_FETCH_PREVIEW_ENABLED
@synthesize moduleRegistry = moduleRegistry_;
#endif // WORKLETS_FETCH_PREVIEW_ENABLED

RCT_EXPORT_MODULE(WorkletsModule);

RCT_EXPORT_BLOCKING_SYNCHRONOUS_METHOD(installTurboModule : (BOOL)bundleModeEnabled)
{
  react_native_assert(self.bridge != nullptr);
  react_native_assert(self.bridge.runtime != nullptr);

  AssertJavaScriptQueue();

  jsi::Runtime &rnRuntime = *reinterpret_cast<facebook::jsi::Runtime *>(self.bridge.runtime);

  std::string sourceURL = "";
  std::shared_ptr<const ScriptBuffer> script = nullptr;

  if (bundleModeEnabled) {
    NSURL *url = bundleManager_.bundleURL;
    script = [self getScript:url];
    sourceURL = [[url absoluteString] UTF8String];
  }

#ifdef WORKLETS_FETCH_PREVIEW_ENABLED
  id networkingModule = [moduleRegistry_ moduleForClass:RCTNetworking.class];
  workletsNetworking_ = [[WorkletsNetworking alloc] init:networkingModule];
#endif // WORKLETS_FETCH_PREVIEW_ENABLED

  auto jsCallInvoker = callInvoker_.callInvoker;
  auto uiScheduler = std::make_shared<IOSUIScheduler>();
  auto isJavaScriptQueue = []() -> bool {
    return IsJavaScriptQueue();
  };
  animationFrameQueue_ = [AnimationFrameQueue new];
  auto runtimeBindings = [self getRuntimeBindings:rnRuntime bundleModeEnabled:bundleModeEnabled];
  rnRuntimeStatus_ = std::make_shared<RNRuntimeStatus>();

  workletsModuleProxy_ = std::make_shared<WorkletsModuleProxy>(
      rnRuntime,
      jsCallInvoker,
      uiScheduler,
      std::move(isJavaScriptQueue),
      runtimeBindings,
      BundleModeConfig{.enabled = static_cast<bool>(bundleModeEnabled), .script = script, .sourceURL = sourceURL},
      rnRuntimeStatus_);

  return @YES;
}

RCT_EXPORT_BLOCKING_SYNCHRONOUS_METHOD(start)
{
  AssertJavaScriptQueue();
  workletsModuleProxy_->start();
  return @YES;
}

RCT_EXPORT_BLOCKING_SYNCHRONOUS_METHOD(toggleSlowAnimationsOnUIRuntime)
{
  throw std::runtime_error("[Worklets] toggleSlowAnimationsOnUIRuntime is not supported on iOS.");
}

- (void)invalidate
{
  AssertTurboModuleManagerQueue();

  [animationFrameQueue_ invalidate];

  if (rnRuntimeStatus_) {
    rnRuntimeStatus_->setDead();
  }
  workletsModuleProxy_.reset();

  [super invalidate];
}

- (std::shared_ptr<facebook::react::TurboModule>)getTurboModule:
    (const facebook::react::ObjCTurboModule::InitParams &)params
{
  AssertJavaScriptQueue();
  return std::make_shared<facebook::react::NativeWorkletsModuleSpecJSI>(params);
}

- (std::shared_ptr<const ScriptBuffer>)getScript:(NSURL *)url
{
  NSData *data = [NSData dataWithContentsOfURL:url];

  if (!data) [[unlikely]] {
    NSString *errorMsg = [NSString stringWithFormat:@"[Worklets] Failed to load worklets bundle from URL: %@", url];
    NSLog(@"%@", errorMsg);
    throw std::runtime_error([errorMsg UTF8String]);
  }

  auto str = std::string(reinterpret_cast<const char *>([data bytes]), [data length]);
  auto bigString = std::make_shared<const JSBigStdString>(str);
  return std::make_shared<const ScriptBuffer>(bigString);
}

- (std::shared_ptr<RuntimeBindings>)getRuntimeBindings:(jsi::Runtime &)rnRuntime
                                     bundleModeEnabled:(BOOL)bundleModeEnabled
{
  return std::make_shared<RuntimeBindings>(RuntimeBindings{
      .requestAnimationFrame = [animationFrameQueue =
                                    animationFrameQueue_](std::function<void(const double)> &&callback) -> void {
        [animationFrameQueue requestAnimationFrame:callback];
      },
      .nativeLoggingHook =
          bundleModeEnabled ? extractNativeLoggingHookFromRNRuntime(rnRuntime) : RuntimeBindings::NativeLoggingHook{}
#ifdef WORKLETS_FETCH_PREVIEW_ENABLED
      ,
      .abortRequest =
          [workletsNetworking = workletsNetworking_](jsi::Runtime &rt, const jsi::Value &requestID) {
            [workletsNetworking jsiAbortRequest:requestID.asNumber()];
            return jsi::Value::undefined();
          },
      .clearCookies =
          [workletsNetworking = workletsNetworking_](jsi::Runtime &rt, jsi::Function &&responseSender) {
            [workletsNetworking jsiClearCookies:rt responseSender:(std::move(responseSender))];
            return jsi::Value::undefined();
          },
      .sendRequest =
          [workletsNetworking = workletsNetworking_](
              jsi::Runtime &rt, const jsi::Value &query, jsi::Function &&responseSender) {
            [workletsNetworking jsiSendRequest:rt jquery:query responseSender:(std::move(responseSender))];
            return jsi::Value::undefined();
          }
#endif // WORKLETS_FETCH_PREVIEW_ENABLED
  });
}

@end
